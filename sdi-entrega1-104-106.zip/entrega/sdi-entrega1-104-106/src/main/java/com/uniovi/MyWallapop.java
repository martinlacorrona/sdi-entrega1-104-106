package com.uniovi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyWallapop {

    public static void main(String[] args) {
	SpringApplication.run(MyWallapop.class, args);
    }

}
