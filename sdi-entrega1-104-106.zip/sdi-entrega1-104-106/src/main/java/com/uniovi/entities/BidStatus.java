package com.uniovi.entities;

public enum BidStatus {
    ACTIVED, DELETED, BUYED;
}
